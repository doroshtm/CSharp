﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ONG_Animal
{
    public partial class FrmAnimal : Form
    {
        public FrmAnimal()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void LblDispo_Click(object sender, EventArgs e)
        {

        }

        private void LblStatusAnimal_Click(object sender, EventArgs e)
        {

        }

        private void TxtSituacao_TextChanged(object sender, EventArgs e)
        {

        }

        private void LblVacinacao_Click(object sender, EventArgs e)
        {

        }

        private void TxtVacinacao_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtDisponivel_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
