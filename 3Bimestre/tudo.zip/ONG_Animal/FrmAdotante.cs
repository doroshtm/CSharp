﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ONG_Animal
{
    public partial class FrmAdotante : Form
    {
        public FrmAdotante()
        {
            InitializeComponent();
        }

        private void LblGenero_Click(object sender, EventArgs e)
        {

        }

        private void TxtGenero_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnNovoAdotante_Click(object sender, EventArgs e)
        {
                           
        }

        private void FrmAdotante_Load(object sender, EventArgs e)
        {

        }

        private void DtpDataNascimento_ValueChanged(object sender, EventArgs e)
        {

        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // FrmAdotante
            // 
            this.ClientSize = new System.Drawing.Size(620, 420);
            this.Name = "FrmAdotante";
            this.ResumeLayout(false);

        }
    }
}
