﻿using System.Windows.Forms;

namespace _3Bimestre
{
    internal class FormMain : Form
    {
    }
}